# Viết chương trình nhập vào 3 chuỗi rồi in thành 3 dòng, mỗi dòng là 1 chuỗi riêng biệt.
# Ví dụ : nhập vào 3 chuỗi (cách nhau bởi 1 khoảng trắng) : Nguyen Van Minh
# Xuất ra :
# Nguyen
# Van
# Minh

str1, str2, str3 = input("Nhập vào 3 chuỗi (cách nhau bởi 1 khoảng trắng) : ").split()
print(str1)
print(str2)
print(str3)