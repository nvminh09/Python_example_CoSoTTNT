# Gộp 2 tập hợp, các phần tử trùng nhau được gộp làm 1

set1 = {1, 2, 333, 444, 555}
set2 = {333, 444, 555, 6, 7}

print(set1.union(set2))