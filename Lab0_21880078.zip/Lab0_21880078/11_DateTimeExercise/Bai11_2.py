# In thời gian hiện tại dạng mili giây
import time

milliseconds = int(round(time.time()))
print(milliseconds)