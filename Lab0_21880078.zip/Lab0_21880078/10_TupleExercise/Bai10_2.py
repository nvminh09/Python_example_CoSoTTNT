# Tạo ra 1 tuple mới từ các phần tử của tuple đã cho

tuple1 = (11, 22, 33, 44, 55, 66)
tuple2 = tuple1[1:-2] # Lấy phần tử có chỉ số 1 tính từ trái sang phải và chỉ số -2 tính từ phải sang trái
print(tuple2)