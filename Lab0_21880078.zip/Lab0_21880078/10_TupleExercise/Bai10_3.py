# Thay giá trị của 1 phần tử trong tuple bằng 1 giá trị khác

tuple1 = (11, [22, 33], 44, 55)
tuple1[1][0] = 22222
print(tuple1)