# Viết hàm in ra các giá trị của biến nhập vào

def func1(*v):
    for i in v:
        print(i)

func1(20, 40, 60, 0, 1, 2)